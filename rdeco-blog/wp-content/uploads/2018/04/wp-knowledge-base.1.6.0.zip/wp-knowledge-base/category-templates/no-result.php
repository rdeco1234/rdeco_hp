<?php
/**
 * @package iPanelThemes Knowledgebase
 */
?>
<div class="list-group-item text-muted">
	<span class="glyphicon ipt-icon-blocked"></span> <?php _e( 'No articles published. Check back later?', 'ipt_kb' ); ?>
</div>
